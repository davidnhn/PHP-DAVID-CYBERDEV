# mvc_util
Correction de l'exercice mvc utilisateur:
-Création d'utilisateur,
-Modification de l'utilisateur,
-Affichage de tous les utilisateurs,
-Suppression d'un ou plusieurs utilisateurs.
Codé en PHP (avec un peu de JS)