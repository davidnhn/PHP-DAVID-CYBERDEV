<nav>
    <ul>
        <li><a href="./index.php">Connexion</a></li>
        <li><a href="./create_user.php">Ajouter utilisateur</a></li>
        <li><a href="./show_all_user.php">Liste des utilisateurs</a></li>
        <li><a href="./deconnected.php">Déconnexion</a></li>
    </ul>
</nav>